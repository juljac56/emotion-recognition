# Emotion recognition

Machine Learning project, the goal is to be able to detect 7 different emotions